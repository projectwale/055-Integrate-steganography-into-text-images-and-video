from stegano import lsb
from PIL import Image
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.asymmetric import padding
from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA
import binascii        
import wave  

# RSA encryption and decryption functions
def rsa_encrypt(text, public_key):
    secret_message = bytes(text, 'utf-8')
    
    encMessage = public_key.encrypt( secret_message ) 
    hexilify= binascii.hexlify(encMessage)
    strencry = str(hexilify.decode('UTF-8'))
    return strencry

def rsa_decrypt(cipher_text, private_key):
    str1 = cipher_text 
    convertedtobyte = bytes(str1, 'utf-8')
    decrypted_data = private_key.decrypt(binascii.unhexlify(convertedtobyte))
    print(decrypted_data)
    str1 = decrypted_data.decode('UTF-8') 
    print(str1)       
    return str1

key = RSA.generate(2048)

# Example usage
if __name__ == "__main__":
    # Path to the original image
    original_image_path = "testfiles/buddy.wav"

    # Text to be hidden as watermark
    watermark_text = "This is a hiddensdfsdf sdfkkdfds ffksdfkjsdf sdfjksdjfkjsdf"
    publicKey = PKCS1_OAEP.new( key )
    encrypted_watermark = rsa_encrypt(watermark_text, publicKey)

    # read wave audio file
    song = wave.open(original_image_path, mode='rb')
    # Read frames and convert to byte array
    frame_bytes = bytearray(list(song.readframes(song.getnframes())))
    
    string = encrypted_watermark
    # Append dummy data to fill out rest of the bytes. Receiver shall detect and remove these characters.
    string = string + int((len(frame_bytes)-(len(string)*8*8))/8) *'#'
    # Convert text to bit array
    bits = list(map(int, ''.join([bin(ord(i)).lstrip('0b').rjust(8,'0') for i in string])))
    
    # Replace LSB of each byte of the audio data by one bit from the text bit array
    for i, bit in enumerate(bits):
        frame_bytes[i] = (frame_bytes[i] & 254) | bit
    # Get the modified bytes
    frame_modified = bytes(frame_bytes)
    
    # Write bytes to a new wave audio file
    with wave.open('watermark_embedded.wav', 'wb') as fd:
        fd.setparams(song.getparams())
        fd.writeframes(frame_modified)
    song.close()

    song1 = wave.open("watermark_embedded.wav", mode='rb')
    # Convert audio to byte array
    frame_bytes = bytearray(list(song1.readframes(song1.getnframes())))
    
    # Extract the LSB of each byte
    extracted = [frame_bytes[i] & 1 for i in range(len(frame_bytes))]
    
    # Convert byte array back to string
    string = "".join(chr(int("".join(map(str,extracted[i:i+8])),2)) for i in range(0,len(extracted),8))
    
    # Cut off at the filler characters
    decoded = string.split("###")[0]
    
    # Print the extracted text
    print("Sucessfully decoded: "+decoded)
         
    public_crypter =  PKCS1_OAEP.new( key )
    decrypted_watermark = rsa_decrypt(decoded, public_crypter)
    print("Retrieved Watermark:", decrypted_watermark)