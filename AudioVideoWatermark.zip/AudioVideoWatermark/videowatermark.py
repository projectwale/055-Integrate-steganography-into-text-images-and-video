from stegano import lsb
from PIL import Image
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.asymmetric import padding
from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA
import binascii        
      
import cv2
import shutil

import math
import os  

# RSA encryption and decryption functions
def rsa_encrypt(text, public_key):
    secret_message = bytes(text, 'utf-8')
    
    encMessage = public_key.encrypt( secret_message ) 
    hexilify= binascii.hexlify(encMessage)
    strencry = str(hexilify.decode('UTF-8'))
    return strencry

def rsa_decrypt(cipher_text, private_key):
    str1 = cipher_text 
    convertedtobyte = bytes(str1, 'utf-8')
    decrypted_data = private_key.decrypt(binascii.unhexlify(convertedtobyte))
    print(decrypted_data)
    str1 = decrypted_data.decode('UTF-8') 
    print(str1)       
    return str1

def split_string(s_str,count=10):
    per_c=math.ceil(len(s_str)/count)
    c_cout=0
    out_str=''
    split_list=[]
    for s in s_str:
        out_str+=s
        c_cout+=1
        if c_cout == per_c:
            split_list.append(out_str)
            out_str=''
            c_cout=0
    if c_cout!=0:
        split_list.append(out_str)
    return split_list

def frame_extraction(video,input_string):    
    split_string_list=split_string(input_string)
    if not os.path.exists("./videowatermarkfolder/"+video.split('.', 1)[0]+"_folder"):
        os.makedirs("videowatermarkfolder/"+video.split('.', 1)[0]+"_folder")
    temp_folder="./videowatermarkfolder/"+video.split('.', 1)[0]+"_folder"
    print("[INFO] tmp directory is created")

    vidcap = cv2.VideoCapture(video)
    count = 0

    while count < len(split_string_list):
        success, image = vidcap.read()
        print(success)
        if not success:
            break
        cv2.imwrite(os.path.join(temp_folder, "{:d}.png".format(count)), image)
        count += 1
        
def encode_string(video,input_string):
    root="./videowatermarkfolder/"+video.split('.', 1)[0]+"_folder/"
    split_string_list=split_string(input_string)
    for i in range(0,len(split_string_list)):
        f_name="{}{}.png".format(root,i)
        secret_enc=lsb.hide(f_name,split_string_list[i])
        secret_enc.save(f_name)
        print("[INFO] frame {} holds {}".format(f_name,split_string_list[i]))
        
def decode_string(video):
    secret=[]
    root="./videowatermarkfolder/"+video.split('_', 1)[0]+"_folder/"
    for i in range(len(os.listdir(root))):
        f_name="{}{}.png".format(root,i)
        secret_dec=lsb.reveal(f_name)
        if secret_dec == None:
            break
        secret.append(secret_dec)
        
    decoded_str = ''.join([i for i in secret])
    # clean_tmp(video)
    print("decoded_str",decoded_str)
    return decoded_str
    
def clean_tmp(video):
    path="./videowatermarkfolder/"+video.split('_', 1)[0]+"_folder"
    if os.path.exists(path):
        shutil.rmtree(path)
        print("[INFO] tmp files are cleaned up")

key = RSA.generate(2048)

# Example usage
if __name__ == "__main__":
    # Path to the original image
    original_image_path = "testfiles/test.mp4"

    # Text to be hidden as watermark
    watermark_text = "This is a hiddensdfsdf sdfkkdfds ffksdfkjsdf sdfjksdjfkjsdf"
    publicKey = PKCS1_OAEP.new( key )
    encrypted_watermark = rsa_encrypt(watermark_text, publicKey)

    input_string = encrypted_watermark
    f_name= original_image_path
    frame_extraction(f_name,input_string)
    
    encode_string(f_name,input_string)
    
    image_folder = "videowatermarkfolder/"+f_name.split('.', 1)[0]+"_folder"
    video_name = "static/watermarkedvideo/"+f_name.split('.', 1)[0]+'_video.mp4'
    
    images = [img for img in os.listdir(image_folder) if img.endswith(".png")]
    frame = cv2.imread(os.path.join(image_folder, images[0]))
    height, width, layers = frame.shape
    
    video = cv2.VideoWriter(video_name, 0, 1, (width,height))
    
    for image in images:
        video.write(cv2.imread(os.path.join(image_folder, image)))
    
    cv2.destroyAllWindows()
    video.release()

    decoded_str = decode_string(f_name.split('.', 1)[0]+'_video.mp4')
    public_crypter =  PKCS1_OAEP.new( key )
    decrypted_watermark = rsa_decrypt(decoded_str, public_crypter)
    print("Retrieved Watermark:", decrypted_watermark)