from flask import Flask, session,render_template,request,redirect,flash
import pymysql
import os
from werkzeug.utils import secure_filename        
import wave        
import cv2
from stegano import lsb
from PIL import Image
import binascii     
import math
import shutil
from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA
import pathlib

app = Flask(__name__)

def dbConnection():
    try:
        connection = pymysql.connect(host="localhost", user="root", password="root", database="audiovideowatermark")
        return connection
    except:
        print("Something went wrong in database Connection")

def dbClose():
    try:
        dbConnection().close()
    except:
        print("Something went wrong in Close DB Connection")

app.secret_key = 'any random string'

con = dbConnection()
cursor = con.cursor()

def split_string(s_str,count=10):
    per_c=math.ceil(len(s_str)/count)
    c_cout=0
    out_str=''
    split_list=[]
    for s in s_str:
        out_str+=s
        c_cout+=1
        if c_cout == per_c:
            split_list.append(out_str)
            out_str=''
            c_cout=0
    if c_cout!=0:
        split_list.append(out_str)
    return split_list


def frame_extraction(video,input_string):  
    split_string_list=split_string(input_string)
    if not os.path.exists(video.split('.', 1)[0]+"_folder"):
        os.makedirs(video.split('.', 1)[0]+"_folder")
    temp_folder=video.split('.', 1)[0]+"_folder"
    print("[INFO] tmp directory is created")

    vidcap = cv2.VideoCapture(video)
    count = 0

    while count < len(split_string_list):
        success, image = vidcap.read()
        print(success)
        if not success:
            break
        cv2.imwrite(os.path.join(temp_folder, "{:d}.png".format(count)), image)
        count += 1

def encode_string(video,input_string):
    root=video.split('.', 1)[0]+"_folder/"
    split_string_list=split_string(input_string)
    for i in range(0,len(split_string_list)):
        f_name="{}{}.png".format(root,i)
        secret_enc=lsb.hide(f_name,split_string_list[i])
        secret_enc.save(f_name)
        print("[INFO] frame {} holds {}".format(f_name,split_string_list[i]))
        
def decode_string(video):
    secret=[]
    root=video.split('.', 1)[0]+"_folder/"
    for i in range(len(os.listdir(root))):
        f_name="{}{}.png".format(root,i)
        secret_dec=lsb.reveal(f_name)
        if secret_dec == None:
            break
        secret.append(secret_dec)
        
    decoded_str = ''.join([i for i in secret])
    # clean_tmp(video)
    # print("decoded_str",decoded_str)
    return decoded_str
    
def clean_tmp(video):
    path=video.split('_', 1)[0]+"_folder"
    if os.path.exists(path):
        shutil.rmtree(path)
        print("[INFO] tmp files are cleaned up")
    
@app.route("/",methods=['POST','GET'])
def index():    
    return render_template('login.html')

@app.route("/register",methods=['POST','GET'])
def register():    
    return render_template('register.html')

@app.route("/main",methods=['POST','GET'])
def main():    
    return render_template('index.html')

@app.route('/logout')
def logout():
    session.pop('name',None)
    return render_template('login.html') 

def rsa_encrypt(text, public_key):
    secret_message = bytes(text, 'utf-8')
    
    encMessage = public_key.encrypt( secret_message ) 
    hexilify= binascii.hexlify(encMessage)
    strencry = str(hexilify.decode('UTF-8'))
    return strencry

def rsa_decrypt(cipher_text, private_key):
    str1 = cipher_text 
    convertedtobyte = bytes(str1, 'utf-8')
    decrypted_data = private_key.decrypt(binascii.unhexlify(convertedtobyte))
    print(decrypted_data)
    str1 = decrypted_data.decode('UTF-8') 
    print(str1)       
    return str1

# Function to add a hidden text watermark to an image
def add_watermark(image_path, output_path, watermark_text):
    image = Image.open(image_path)
    watermarked_image = lsb.hide(image, watermark_text)
    watermarked_image.save(output_path)

def retrieve_watermark(image_path):
    watermarked_image = Image.open(image_path)
    print(watermarked_image)
    watermark_text = lsb.reveal(watermarked_image)
    return watermark_text

@app.route("/checkRegister",methods=['POST','GET'])
def checkRegister():   
    if request.method == "POST": 
        details = request.form
        
        username = details['username']
        email = details['email']
        mobile = details['mobile']
        password = details['password']
        
        cursor.execute('SELECT * FROM register WHERE username = %s', (username))
        count = cursor.rowcount
        print(count)
        if count == 1: 
            return "fail"      
        else:
            sql1 = "INSERT INTO register(username,email,mobile,password)VALUES(%s,%s,%s,%s);"
            val1 = (username,email,mobile,password)
            cursor.execute(sql1,val1)
            con.commit()
            return "success"      

@app.route('/SessionHandle',methods=['POST','GET'])
def SessionHandle():
    if request.method == "POST":
        details = request.form
        username = details['username']
        password = details['password']
        
        cursor.execute('SELECT * FROM register WHERE username = %s AND password = %s', (username,password))
        count = cursor.rowcount
        if count == 1:
            session['name'] = username
            return "success"
        else:
            return "fail"   
        
@app.route("/addAudioWatermark",methods=['POST','GET'])
def addAudioWatermark():
    if request.method == "POST":      
        audiofile = request.files['audiofile']
        watermarktext = request.form['watermarktext'] 
        
        filename_secure = secure_filename(audiofile.filename)
        pathlib.Path('static/watermarkedaudio/',filename_secure.split('.', 1)[0]+'_embedded').mkdir(exist_ok=True)
        audiofile.save('static/watermarkedaudio/'+filename_secure.split('.', 1)[0]+'_embedded'+'/'+filename_secure.split('.', 1)[0]+'.wav')
        filename1 = 'static/watermarkedaudio/'+filename_secure.split('.', 1)[0]+'_embedded'+'/'+filename_secure.split('.', 1)[0]+'.wav' 
        
        key = RSA.generate(2048)
        publicKey = PKCS1_OAEP.new( key )
        encrypted_watermark = rsa_encrypt(watermarktext, publicKey)
        
        print("Ciper text")
        print(encrypted_watermark)
        
        # read wave audio file
        song = wave.open(filename1, mode='rb')
        # Read frames and convert to byte array
        frame_bytes = bytearray(list(song.readframes(song.getnframes())))
        
        string = encrypted_watermark
        # Append dummy data to fill out rest of the bytes. Receiver shall detect and remove these characters.
        string = string + int((len(frame_bytes)-(len(string)*8*8))/8) *'#'
        # Convert text to bit array
        bits = list(map(int, ''.join([bin(ord(i)).lstrip('0b').rjust(8,'0') for i in string])))
        
        # Replace LSB of each byte of the audio data by one bit from the text bit array
        for i, bit in enumerate(bits):
            frame_bytes[i] = (frame_bytes[i] & 254) | bit
        # Get the modified bytes
        frame_modified = bytes(frame_bytes)
        
        with open('static/watermarkedaudio/'+filename_secure.split('.', 1)[0]+'_embedded'+'/'+'private_key.pem', 'wb' ) as f:
            f.write( key.exportKey( 'PEM' ))
        
        # Write bytes to a new wave audio file
        with wave.open('static/watermarkedaudio/'+filename_secure.split('.', 1)[0]+'_embedded'+'/'+filename_secure.split('.', 1)[0]+'.wav', 'wb') as fd:
            fd.setparams(song.getparams())
            fd.writeframes(frame_modified)
        song.close()        
                
        flash('Watermark added !')
        return redirect("/addAudioWatermark")
        
        return render_template('addaudiowatermark.html')      
        
    return render_template('addaudiowatermark.html')

@app.route("/getAudioWatermark",methods=['POST','GET'])
def getAudioWatermark():
    if request.method == "POST": 
        watermarkfile = request.files['watermarkfile']
        
        filename_secure = secure_filename(watermarkfile.filename)
        watermarkfile.save("song_embedded.wav")
        
        song = wave.open("song_embedded.wav", mode='rb')
        # Convert audio to byte array
        frame_bytes = bytearray(list(song.readframes(song.getnframes())))
        
        # Extract the LSB of each byte
        extracted = [frame_bytes[i] & 1 for i in range(len(frame_bytes))]
        
        # Convert byte array back to string
        string = "".join(chr(int("".join(map(str,extracted[i:i+8])),2)) for i in range(0,len(extracted),8))
        
        # Cut off at the filler characters
        decoded = string.split("###")[0]
        
        song.close()  
        
        with open('static/watermarkedaudio/'+filename_secure.split('.', 1)[0]+'_embedded'+'/'+'private_key.pem','r' ) as f:
            key = RSA.importKey( f.read() )
        
        public_crypter =  PKCS1_OAEP.new( key )
        decrypted_watermark = rsa_decrypt(decoded, public_crypter)
        os.remove("song_embedded.wav")
        return decrypted_watermark  
        
    return render_template('getAudioWatermark.html')
    
@app.route("/addVideowatermark",methods=['POST','GET'])
def addVideowatermark():
    if request.method == "POST": 
     
        videofile = request.files['videofile']
        watermarktext = request.form['watermarktext'] 
        
        filename_secure = secure_filename(videofile.filename)
        pathlib.Path('static/watermarkedvideo/',filename_secure.split('.', 1)[0]+'_embedded').mkdir(exist_ok=True)
        videofile.save('static/watermarkedvideo/'+filename_secure.split('.', 1)[0]+'_embedded'+'/'+filename_secure.split('.', 1)[0]+'.mp4')
        filename1 = 'static/watermarkedvideo/'+filename_secure.split('.', 1)[0]+'_embedded'+'/'+filename_secure.split('.', 1)[0]+'.mp4' 
        
        key = RSA.generate(2048)
        publicKey = PKCS1_OAEP.new( key )
        encrypted_watermark = rsa_encrypt(watermarktext, publicKey)
        
        input_string = encrypted_watermark
        f_name= filename1
        frame_extraction(f_name,input_string)
        
        encode_string(f_name,input_string)
        
        image_folder = 'static/watermarkedvideo/'+filename_secure.split('.', 1)[0]+'_embedded/'+filename_secure.split('.', 1)[0]+"_folder"
        video_name = "static/watermarkedvideo/"+filename_secure.split('.', 1)[0]+'_embedded/'+filename_secure.split('.', 1)[0]+'.mp4'
        
        images = [img for img in os.listdir(image_folder) if img.endswith(".png")]
        frame = cv2.imread(os.path.join(image_folder, images[0]))
        height, width, layers = frame.shape
        
        video = cv2.VideoWriter(video_name, 0, 1, (width,height))
        
        for image in images:
            video.write(cv2.imread(os.path.join(image_folder, image)))
        
        cv2.destroyAllWindows()
        video.release()
        
        with open('static/watermarkedvideo/'+filename_secure.split('.', 1)[0]+'_embedded'+'/'+'private_key.pem', 'wb' ) as f:
            f.write( key.exportKey( 'PEM' ))
        
        flash('Watermark added !')
        return redirect("/addVideowatermark")
        
    return render_template('addVideowatermark.html')

@app.route("/getVideoWatermark",methods=['POST','GET'])
def getVideoWatermark():
    if request.method == "POST":  
        # try:
        videowatermarkfile = request.files['videowatermarkfile']
        
        filename_secure = secure_filename(videowatermarkfile.filename)        
        decoded_str = decode_string("static/watermarkedvideo/"+filename_secure.split('.', 1)[0]+'_embedded/'+filename_secure.split('.', 1)[0]+'.mp4')
        
        with open('static/watermarkedvideo/'+filename_secure.split('.', 1)[0]+'_embedded'+'/'+'private_key.pem','r' ) as f:
            key = RSA.importKey( f.read() )
    
        public_crypter =  PKCS1_OAEP.new( key )
        decrypted_watermark = rsa_decrypt(decoded_str, public_crypter)
        return decrypted_watermark  
        # except:
        #     return "fail"    
        
    return render_template('getVideoWatermark.html')

@app.route("/addimagewatermark", methods=['POST', 'GET'])
def addimagewatermark():
    if request.method == "POST":
        imagefile = request.files['imagefile']
        watermark_text = request.form['watermarktext']

        filename_secure = secure_filename(imagefile.filename)
        pathlib.Path('static/watermarkedimages/',filename_secure.split('.', 1)[0]+'_embedded').mkdir(exist_ok=True)
        imagefile.save(filename_secure)
        filename1 = 'static/watermarkedimages/'+filename_secure.split('.', 1)[0]+'_embedded'+'/'+filename_secure.split('.', 1)[0]+'.png' 

        watermarked_image_path = filename1
        
        key = RSA.generate(2048)
        publicKey = PKCS1_OAEP.new( key )
        encrypted_watermark = rsa_encrypt(watermark_text, publicKey)
        print(encrypted_watermark)
        add_watermark(filename_secure, watermarked_image_path, encrypted_watermark)
       
        with open('static/watermarkedimages/'+filename_secure.split('.', 1)[0]+'_embedded'+'/'+'private_key.pem', 'wb' ) as f:
            f.write( key.exportKey( 'PEM' ))
            
        os.remove(filename_secure)
        flash('Watermark added to the image!')
        return redirect("/addimagewatermark")
    return render_template('addimagewatermark.html')

@app.route("/getImageWatermark", methods=['POST', 'GET'])
def getImageWatermark():
    if request.method == "POST":
        imagefile = request.files['watermarkfile']
    
        filename_secure = secure_filename(imagefile.filename)
        imagefile.save(filename_secure)
        
        retrieved_watermark = retrieve_watermark(filename_secure)
        
        print(retrieved_watermark)
        with open('static/watermarkedimages/'+filename_secure.split('.', 1)[0]+'_embedded'+'/'+'private_key.pem','r' ) as f:
            key = RSA.importKey( f.read() )
            
        private_crypter = PKCS1_OAEP.new(key)
        retrieved_watermark = rsa_decrypt(retrieved_watermark, private_crypter)
        
        os.remove(filename_secure)
        if retrieved_watermark is not None:
            print("Retrieved Watermark:", retrieved_watermark)
            return retrieved_watermark
        else:
            print("No watermark found in the image.")
            return "No watermark found in the image."
        
    return render_template('getImageWatermark.html')

if __name__ == '__main__':
    app.run('0.0.0.0')