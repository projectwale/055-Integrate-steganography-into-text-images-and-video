from flask import Flask, session,render_template,request,redirect,flash,url_for,jsonify
import pymysql
import os
from werkzeug.utils import secure_filename        
import wave        
import cv2
import os
import math
from stegano import lsb
import shutil
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
import base64
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
import binascii
from PIL import Image, ImageDraw
import io

app = Flask(__name__)

UPLOAD_AUDIO_FOLDER = 'static/audiofiles/'
app.config['UPLOAD_AUDIO_FOLDER'] = UPLOAD_AUDIO_FOLDER

UPLOAD_IMAGE_FOLDER = 'static/watermarkedimages/'
app.config['UPLOAD_IMAGE_FOLDER'] = UPLOAD_IMAGE_FOLDER

def dbConnection():
    try:
        connection = pymysql.connect(host="localhost", user="root", password="root", database="audiovideowatermark")
        return connection
    except:
        print("Something went wrong in database Connection")

def dbClose():
    try:
        dbConnection().close()
    except:
        print("Something went wrong in Close DB Connection")

app.secret_key = 'any random string'

con = dbConnection()
cursor = con.cursor()

def split_string(s_str,count=10):
    per_c=math.ceil(len(s_str)/count)
    c_cout=0
    out_str=''
    split_list=[]
    for s in s_str:
        out_str+=s
        c_cout+=1
        if c_cout == per_c:
            split_list.append(out_str)
            out_str=''
            c_cout=0
    if c_cout!=0:
        split_list.append(out_str)
    return split_list


def frame_extraction(video,input_string):    
    split_string_list=split_string(input_string)
    if not os.path.exists("./videowatermarkfolder/"+video.split('.', 1)[0]+"_folder"):
        os.makedirs("videowatermarkfolder/"+video.split('.', 1)[0]+"_folder")
    temp_folder="./videowatermarkfolder/"+video.split('.', 1)[0]+"_folder"
    print("[INFO] tmp directory is created")

    vidcap = cv2.VideoCapture(video)
    count = 0

    while count < len(split_string_list):
        success, image = vidcap.read()
        print(success)
        if not success:
            break
        cv2.imwrite(os.path.join(temp_folder, "{:d}.png".format(count)), image)
        count += 1

def encode_string(video,input_string):
    root="./videowatermarkfolder/"+video.split('.', 1)[0]+"_folder/"
    split_string_list=split_string(input_string)
    for i in range(0,len(split_string_list)):
        f_name="{}{}.png".format(root,i)
        secret_enc=lsb.hide(f_name,split_string_list[i])
        secret_enc.save(f_name)
        print("[INFO] frame {} holds {}".format(f_name,split_string_list[i]))
        
def decode_string(video):
    secret=[]
    root="./videowatermarkfolder/"+video.split('_', 1)[0]+"_folder/"
    for i in range(len(os.listdir(root))):
        f_name="{}{}.png".format(root,i)
        secret_dec=lsb.reveal(f_name)
        if secret_dec == None:
            break
        secret.append(secret_dec)
        
    decoded_str = ''.join([i for i in secret])
    # clean_tmp(video)
    print("decoded_str",decoded_str)
    return decoded_str
    
def clean_tmp(video):
    path="./videowatermarkfolder/"+video.split('_', 1)[0]+"_folder"
    if os.path.exists(path):
        shutil.rmtree(path)
        print("[INFO] tmp files are cleaned up")
    
@app.route("/",methods=['POST','GET'])
def index():    
    return render_template('login.html')

@app.route("/register",methods=['POST','GET'])
def register():    
    return render_template('register.html')

@app.route("/main",methods=['POST','GET'])
def main():    
    return render_template('index.html')

@app.route('/logout')
def logout():
    session.pop('name',None)
    return render_template('login.html') 

@app.route("/checkRegister",methods=['POST','GET'])
def checkRegister():   
    if request.method == "POST": 
        details = request.form
        
        username = details['username']
        email = details['email']
        mobile = details['mobile']
        password = details['password']
        
        cursor.execute('SELECT * FROM register WHERE username = %s', (username))
        count = cursor.rowcount
        print(count)
        if count > 0: 
            return "fail"      
        else:
            sql1 = "INSERT INTO register(username,email,mobile,password)VALUES(%s,%s,%s,%s);"
            val1 = (username,email,mobile,password)
            cursor.execute(sql1,val1)
            con.commit()
            return "success"      

@app.route('/SessionHandle',methods=['POST','GET'])
def SessionHandle():
    if request.method == "POST":
        details = request.form
        username = details['username']
        password = details['password']
        
        cursor.execute('SELECT * FROM register WHERE username = %s AND password = %s', (username,password))
        count = cursor.rowcount
        if count > 0:
            session['name'] = username
            return "success"
        else:
            return "fail"   

def rsa_encrypt(text, public_key):
    secret_message = bytes(text, 'utf-8')
    
    encMessage = public_key.encrypt( secret_message ) 
    hexilify= binascii.hexlify(encMessage)
    strencry = str(hexilify.decode('UTF-8'))
    return strencry

def rsa_decrypt(cipher_text, private_key):
    str1 = cipher_text 
    convertedtobyte = bytes(str1, 'utf-8')
    decrypted_data = private_key.decrypt(binascii.unhexlify(convertedtobyte))
    print(decrypted_data)
    str1 = decrypted_data.decode('UTF-8') 
    print(str1)       
    return str

key = RSA.generate(2048)
public_key = PKCS1_OAEP.new( key )
private_key =  PKCS1_OAEP.new( key )
# -----------------------------------------------------------------------------------------------------------------

@app.route("/addAudioWatermark", methods=['POST', 'GET'])
def addAudioWatermark():
    
    if request.method == "POST":
        audiofile = request.files['audiofile']
        watermarktext = request.form['watermarktext']

        filename_secure = secure_filename(audiofile.filename)
        audiofile.save(os.path.join(app.config['UPLOAD_AUDIO_FOLDER'], filename_secure))
        filename1 = os.path.join(app.config['UPLOAD_AUDIO_FOLDER'], filename_secure)
        
        # Encrypt the watermark text using RSA
        encrypted_watermark = rsa_encrypt(watermarktext, public_key)
        print(encrypted_watermark)

        # Read wave audio file
        song = wave.open(filename1, mode='rb')
        # Read frames and convert to byte array
        frame_bytes = bytearray(list(song.readframes(song.getnframes())))

        # Convert encrypted watermark to base64 for easier handling
        encrypted_watermark_base64 = base64.b64encode(encrypted_watermark.encode()).decode()
        print(encrypted_watermark_base64)

        # Append dummy data to fill out rest of the bytes. Receiver shall detect and remove these characters.
        encrypted_watermark_base64 = encrypted_watermark_base64 + int((len(frame_bytes) - (len(encrypted_watermark_base64) * 8 * 8)) / 8) * '#'
        # Convert text to bit array
        bits = list(map(int, ''.join([bin(ord(i)).lstrip('0b').rjust(8, '0') for i in encrypted_watermark_base64])))

        # Replace LSB of each byte of the audio data by one bit from the text bit array
        for i, bit in enumerate(bits):
            frame_bytes[i] = (frame_bytes[i] & 254) | bit
        # Get the modified bytes
        frame_modified = bytes(frame_bytes)

        # Write bytes to a new wave audio file
        with wave.open('static/watermarkedaudio/' + filename_secure.split('.', 1)[0] + '_embedded.wav', 'wb') as fd:
            fd.setparams(song.getparams())
            fd.writeframes(frame_modified)
        song.close()

        flash('Watermark added!')
        return redirect("/addAudioWatermark")

    return render_template('addaudiowatermark.html')

@app.route("/getAudioWatermark", methods=['POST', 'GET'])
def getAudioWatermark():
    
    if request.method == "POST":
        watermarkfile = request.files['watermarkfile']
        
        filename_secure = secure_filename(watermarkfile.filename)
        watermarkfile.save("song_embedded.wav")
        
        song = wave.open("song_embedded.wav", mode='rb')
        # Convert audio to byte array
        frame_bytes = bytearray(list(song.readframes(song.getnframes())))
        
        # Extract the LSB of each byte
        extracted = [frame_byte & 1 for frame_byte in frame_bytes]
        
        # Convert byte array back to string
        string = "".join(chr(int("".join(map(str, extracted[i:i+8])), 2)) for i in range(0, len(extracted), 8))
        
        # Cut off at the filler characters
        decoded = string.split("###")[0]
        
        # Convert decoded string to bytes
        decoded_bytes = base64.b64decode(decoded.encode())
        
        # Decrypt using RSA private key
        decrypted_watermark = rsa_decrypt(decoded_bytes, private_key)
        
        # Print the extracted watermark
        print("Successfully decoded: " + decrypted_watermark)
        song.close()        
        return decrypted_watermark  
        
    return render_template('getAudioWatermark.html')

# -----------------------------------------------------------------------------------------------------------------

@app.route("/addVideowatermark", methods=['POST', 'GET'])
def addVideowatermark():
    if request.method == "POST": 
        videofile = request.files['videofile']
        watermarktext = request.form['watermarktext'] 
        
        # Encrypt the watermark text
        encrypted_cipher = encrypt_text(watermarktext, public_key_video)
        print(encrypted_cipher)
        
        filename_secure = secure_filename(videofile.filename)
        videofile.save(filename_secure)
        filename1 = os.path.join(filename_secure) 
        
        input_string = encrypted_cipher  # Use the encrypted cipher as input
        f_name= filename1
        frame_extraction(f_name, input_string)
        encode_string(f_name, input_string)
        
        image_folder = "./videowatermarkfolder/" + f_name.split('.', 1)[0] + "_folder"
        video_name = "static/watermarkedvideo/" + f_name.split('.', 1)[0] + '_video.mp4'
        
        images = [img for img in os.listdir(image_folder) if img.endswith(".png")]
        frame = cv2.imread(os.path.join(image_folder, images[0]))
        height, width, layers = frame.shape
        
        video = cv2.VideoWriter(video_name, 0, 1, (width, height))
        
        for image in images:
            video.write(cv2.imread(os.path.join(image_folder, image)))
        
        cv2.destroyAllWindows()
        video.release()
        
        flash('Watermark added !')
        return redirect("/addVideowatermark")
        
    return render_template('addVideowatermark.html')

@app.route("/getVideoWatermark",methods=['POST','GET'])
def getVideoWatermark():
    if request.method == "POST":  
        try:
            videowatermarkfile = request.files['videowatermarkfile']
            
            filename_secure = secure_filename(videowatermarkfile.filename)        
            decoded_str = decode_string(filename_secure)  # Assuming decode_string is a function to extract the watermark from the video
            
            # Decrypt the cipher
            decrypted_text = decrypt_cipher(decoded_str, private_key_video)
            print("Successfully decoded: " + decrypted_text)
        
            return decrypted_text  
        except Exception as e:
            print(str(e))
            return "fail"    
        
    return render_template('getVideoWatermark.html')
    
@app.route("/addImageWatermark", methods=['POST', 'GET'])
def addImageWatermark():
    global publicKey
    if request.method == "POST":
        imagefile = request.files['imagefile']
        watermark_text = request.form['watermarktext']

        # Save the uploaded image file
        filename_secure = secure_filename(imagefile.filename)
        imagefile.save(os.path.join(app.config['UPLOAD_AUDIO_FOLDER'], filename_secure))
        original_image_path = os.path.join(app.config['UPLOAD_AUDIO_FOLDER'], filename_secure)
        
        watermarked_image_path = "static/watermarkedimages/watermarked_image.png"
        publicKey = PKCS1_OAEP.new( key )
        watermark_text = rsa_encrypt_image(watermark_text, publicKey)
        print(watermark_text)
        
        # Add watermark to the image
        add_watermark_image(original_image_path, watermarked_image_path, watermark_text)
       
        
        flash('Watermark added to the image!')
        return redirect("/addImageWatermark")
    return render_template('addimagewatermark.html')

@app.route("/getImageWatermark", methods=['POST', 'GET'])
def getImageWatermark():
    if request.method == "POST":
        try:
            watermarkfile = request.files['watermarkfile']
            filename_secure = secure_filename(watermarkfile.filename)
            watermarkfile.save(os.path.join(app.config['UPLOAD_IMAGE_FOLDER'], filename_secure))
            watermarked_image_path = os.path.join(app.config['UPLOAD_IMAGE_FOLDER'], filename_secure)
            print("Watermarked Image Path:", watermarked_image_path)
            
            # Retrieve the watermark from the watermarked image
            retrieved_watermark = retrieve_watermark(watermarked_image_path)
            private_crypter = PKCS1_OAEP.new(private_key_i)

            retrieved_watermark = rsa_decrypt_image(retrieved_watermark, private_crypter)
            
            if retrieved_watermark is not None:
                print("Retrieved Watermark:", retrieved_watermark)
                return retrieved_watermark
            else:
                print("No watermark found in the image.")
                return "No watermark found in the image."
        except Exception as e:
            print("Error:", e)
            return "fail"
    return render_template('getImageWatermark.html')

if __name__ == '__main__':
    app.run('0.0.0.0')
    # app.run(debug=True)